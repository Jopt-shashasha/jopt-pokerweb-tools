# 大会情報登録：Codex Skill＋MCP

同僚本人のCodexが2つのポータルを読み比べ、FAQ Appの大会情報を登録するための初版です。AIの判断はCodex、業務ルールとJSON検証はローカルMCP、最終保存は会社のGoogleアカウントで開いた既存Appが担当します。MCP単体でGoogle資料を読んだり、Google/Harnessに書き込んだりはしません。

## 同僚の初回設定

1. このフォルダーを自分のPCに保存します。Node.js 20以上が必要です。
2. Windowsでは `install.ps1`、またはこのフォルダーで `node scripts/install.mjs` を実行します。Skillとstdio MCPを本人のCodex設定に追加します。他のMCP設定は変更しません。
3. Codexを再起動します。MCP名は `jopt_faq_events`、Skill名は `$jopt-event-register` です。
4. 自分の会社Googleアカウントでポータル2件とFAQ Appを開けることを確認します。Codexには本人のGoogle連携またはブラウザー操作が必要です。共通トークン、他人のCookie、作成者のアカウントは配布しません。

## 毎回送る内容

> $jopt-event-register で大会情報を登録してください。大会名：○○。大会ポータル：URL。受付ポータル：URL。確認できない項目は空欄にして、保存前に確認させてください。

Codexが根拠を確認して導入JSONを作成します。Appの「開催大会」→「AIの登録内容を取り込む」でファイルを選ぶかJSONを貼り付け、「内容を確認」を押します。変更点・出典・未確定事項・LINE表示状態を確認して保存します。Googleログインは従来のままです。更新対象の大会IDは大会編集画面に表示されます。

## 第一版の範囲

- 入力：大会名、ブランド、日程、会場、公開ガイド、追加入場制限。写真アルバム・フォーム・年齢の基本回答は共通情報から引用します。
- 取得・意味判断はCodex。MCPは `get_workflow_rules`、`get_import_schema`、`validate_event_import`、`prepare_event_import` を提供します。
- MCPはJSONの形式・出典の有無・禁止フィールド・渡された既存一覧との重複を検証します。意味的な正確性を保証しません。
- Appは保存直前に重複と対象レコードの変更を再確認します。古いプレビューは拒否します。未確定項目で既存値は消しません。新規大会は非表示が既定です。
- 既存大会を確実に特定できない場合、更新せず質問します。開催回の表記揺れまで完全自動で同一判定する機能はありません。
- JSONには必要な短い引用だけを含めます。内部パスワード、名簿、資格情報は含めません。ローカルJSONは本人の `.codex/jopt-faq/imports/` に保存します。
- App保存はHarnessへの公開とは別です。LINEへの公開、Bot設定変更、業務ルールの自動学習は行いません。

## ルールを改善する場所

正本は `shared/rules.json` と `skills/jopt-event-register/SKILL.md` です。人が確認した業務ルールを追記し、テストして配布・再インストールします。インストール済みコピーは自動更新されません。MCPは起動時にルールファイルを読み込むため、更新後はMCP再起動も行います。

開発確認：`npm test`。Apps Scriptへの組み込み：`node scripts/build-app.mjs`。組み込み後、既存のデプロイを新バージョンへ更新します。配布物にはGoogleやCodexの認証情報を含みません。

仕様参照：[OpenAI Skills](https://developers.openai.com/plugins/concepts/skills)、[Codex MCP](https://learn.chatgpt.com/docs/extend/mcp)、[MCP stdio](https://modelcontextprotocol.io/specification/2025-03-26/basic/transports)。

import {readFile,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
const root=new URL('../',import.meta.url);
const app=new URL('../../../apps-script/jopt-line-faq/',import.meta.url);
const contract=await readFile(new URL('shared/contract.cjs',root),'utf8');
const bridge=await readFile(new URL('apps-script/bridge.gs',root),'utf8');
const marker='// BEGIN JOPT CODEX EVENT IMPORT';
let code=await readFile(new URL('Code.gs',app),'utf8');
code=code.split(marker)[0].trimEnd()+'\n\n'+marker+'\n'+contract+'\n'+bridge+'\n';
let html=await readFile(new URL('Simple.html',app),'utf8');
if(!html.includes('id="evImport"')){
  html=html.replace('＋ 大会を追加</button>`;', '＋ 大会を追加</button><button class="tadd" id="evImport" style="padding:9px">AIの登録内容を取り込む</button>`;');
  html=html.replace('$("#evAdd").onclick=async()=>{','$("#evImport").onclick=()=>{if(!leave())return;sel="event-import";renderEditor();};\n    $("#evAdd").onclick=async()=>{');
  html=html.replace('if(sel==="common") return commonEditor(el);','if(sel==="event-import") return eventImportEditor(el);\n  if(sel==="common") return commonEditor(el);');
  html=html.replace('<div class="path">開催大会</div>','<div class="path">開催大会</div><p class="hint">大会ID：<code>${esc(e.id)}</code></p>');
}
const start='/* BEGIN CODEX IMPORT UI */', end='/* END CODEX IMPORT UI */';
if(html.includes(start)) html=html.slice(0,html.indexOf(start))+html.slice(html.indexOf(end)+end.length);
const ui=await readFile(new URL('apps-script/import-ui.js',root),'utf8');
html=html.replace('/* ---------- LINEで試す ---------- */',start+'\n'+ui+'\n'+end+'\n/* ---------- LINEで試す ---------- */');
html=html.replace('`（${k}未入力）`',"'現在、詳細を確認中です。最新の情報は公式のお知らせをご確認ください。'");
if(!html.includes('id="evImport"')||!html.includes('function eventImportEditor'))throw Error('App insertion failed');
for(const m of html.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g))new Function(m[1]);
new Function(code);
await writeFile(new URL('Code.gs',app),code);await writeFile(new URL('Simple.html',app),html);
console.log('App import bridge built:',fileURLToPath(app));
